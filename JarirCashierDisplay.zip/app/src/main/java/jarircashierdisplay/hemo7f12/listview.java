package jarircashierdisplay.hemo7f12;

public class listview {
    public String cp;
    public int img1;
    public int img2;
    public int img3;

    public listview(String cp, int img1, int img2, int img3) {
        this.cp = cp;
        this.img1 = img1;
        this.img2 = img2;
        this.img3 = img3;
    }
    public String getCp() {
        return this.cp;
    }

    public int getImg1() {
        return img1;
    }
    public int getImg2() {
        return img2;
    }
    public int getImg3() {
        return img3;
    }
}
