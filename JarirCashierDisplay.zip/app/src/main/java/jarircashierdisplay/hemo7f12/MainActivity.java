package jarircashierdisplay.hemo7f12;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.security.Permission;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.PermissionChecker;

@SuppressWarnings("ALL")
public class MainActivity extends AppCompatActivity {
    int [] img = {
            R.drawable.ct,
            R.drawable.ct,
            R.drawable.ct,
            R.drawable.ct,
            R.drawable.ct,
            R.drawable.ct,
            R.drawable.ct,
            R.drawable.ct,
            R.drawable.ct,
            R.drawable.ct
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //حذف شريط التنبيهات
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        ListView list = (ListView) findViewById(R.id.list_view);
        String [] cashierposition = getResources().getStringArray(R.array.cashierposition);
        ArrayList<listview> cashiersList = new ArrayList<listview>();

        for (int i = 0 ; i < cashierposition.length ; i++){
            cashiersList.add(new listview(cashierposition[i],img[i],img[i],img[i]));
        }
        ListAdapter ad = new ListAdapter(cashiersList);
        list.setAdapter(ad);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                TextView cashierposition = (TextView) view.findViewById(R.id.cashier_number);
                Toast.makeText(MainActivity.this, cashierposition.getText(), Toast.LENGTH_SHORT).show();

                ImageView imageleft = (ImageView) view.findViewById(R.id.cashier_left);
                ImageView imageend = (ImageView) view.findViewById(R.id.cashier_end);
                ImageView imageright = (ImageView) view.findViewById(R.id.cashier_right);
            }
        });
    }

    class ListAdapter extends BaseAdapter {
        ArrayList<listview> listview = new ArrayList<listview>();
        Context context;

        int cl = R.drawable.ct;
        ListAdapter(ArrayList<listview> listview) {
            this.listview = listview;
        }


        @Override
        public int getCount() {
            return listview.size();
        }

        @Override
        public Object getItem(int position) {
            return listview.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View view = inflater.inflate(R.layout.cashier_position, parent, false);

            TextView cashierposition = (TextView) view.findViewById(R.id.cashier_number);
            final ImageView imageleft = (ImageView) view.findViewById(R.id.cashier_left);
            ImageView imageend = (ImageView) view.findViewById(R.id.cashier_end);
            ImageView imageright = (ImageView) view.findViewById(R.id.cashier_right);

            cashierposition.setText(listview.get(position).cp);
            imageleft.setImageResource(listview.get(position).img1);
            imageend.setImageResource(listview.get(position).img2);
            imageright.setImageResource(listview.get(position).img3);

            final int i = position + 1;


            imageleft.setOnClickListener(new View.OnClickListener() {
                int REQUEST_IMAGE_CAPTURE = 0;

                public boolean onCreateOptionsMenu(Menu menu) {
                    getMenuInflater().inflate(android.R.menu.class.getModifiers(), menu);
                    return true;
                }
                @Override
                public void onClick(View v) {

                    final CharSequence[] options = { "Preview", "Take Photo", "Choose from Gallery", "Delete", "Cancel" };
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("Add Photo!");
                    builder.setItems(options, new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int item) {
                            if (options[item].equals("Take Photo")) {
                                if (checkSelfPermission(Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED){
                                    REQUEST_IMAGE_CAPTURE ++;
                                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                    startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);                                } else {
                                    if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                                        Toast.makeText(MainActivity.this, "Camera permission was not accepted", Toast.LENGTH_SHORT).show();
                                    }
                                requestPermissions(new String[]{Manifest.permission.CAMERA},REQUEST_IMAGE_CAPTURE);
                                }

                            } else if (options[item].equals("Choose from Gallery")) {
                                REQUEST_IMAGE_CAPTURE ++;
                                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                intent.setType("image/");
                                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);

                            } else if (options[item].equals("Preview")) {
                                Intent intent = new Intent(Intent.ACTION_VIEW);
                                intent.setType("image/*");
                                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);

                            } else if (options[item].equals("Delete")) {
                                imageleft.setImageResource(R.drawable.ct);

                            } else if (options[item].equals("Cancel")) {
                                dialog.dismiss();
                            }

                        }
                    });
                    builder.show();

                        }
                protected void onActivityResult (int requestCode, int resultCode, Intent data){

//                    MainActivity.super.onActivityResult(requestCode, resultCode, data);
                    if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
                        Bundle extras = data.getExtras();
                        Bitmap imageBitmap = (Bitmap) extras.get("data");
                        imageleft.setImageBitmap(imageBitmap);
                        imageleft.setImageResource(Integer.intvalue(),(listview.get(0)));

                    }


                }
                    });

            imageend.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(MainActivity.this, i+ " imageendd", Toast.LENGTH_SHORT).show();
                }
            });

            imageright.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(MainActivity.this, i+ " imagerightt", Toast.LENGTH_SHORT).show();
                }
            });
            return view;
        }
    }



}

